'use strict';

(function(window, $) {
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
})(window, jQuery);
