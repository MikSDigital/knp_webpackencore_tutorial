let foods = new Set();
foods.add('gelato');
foods.add('tortas');
foods.add('gelato');

console.log(foods);
